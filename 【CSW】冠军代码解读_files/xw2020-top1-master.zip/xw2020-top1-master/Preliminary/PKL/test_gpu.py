
from tensorflow.python.client import device_lib
print('#'*30)
print('#'*30)
print(device_lib.list_local_devices())
print('#'*30)
print('#'*30)